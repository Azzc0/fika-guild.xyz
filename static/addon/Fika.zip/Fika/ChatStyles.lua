local addonName, addonTable = ...
addonTable.version = GetAddOnMetadata(addonName, "Version") or "1.0.0"
addonTable.networkDisabled = false

-- Store original AddMessage functions to maintain UI integrity
local OriginalAddMessage = {}
local pendingVersionBroadcast = nil -- Tracks smart suppression ticker handle
addonTable.ignoredTestSenders = {} -- Track session-muted testers

-- Helper to convert "X.Y.Z" string into three separate numbers
local function ParseVersionString(versionStr)
    if not versionStr or type(versionStr) ~= "string" then return 0, 0, 0 end
    local x, y, z = versionStr:match("^(%d+)%.(%d+)%.(%d+)")
    return tonumber(x) or 0, tonumber(y) or 0, tonumber(z) or 0
end

-- Dynamically fetches class hex color string for any guild member by name
local function GetGuildClassColorHex(targetName)
    if not targetName or targetName == "" then return "9e9e9e" end
    
    targetName = targetName:gsub("%s+", ""):lower()
    targetName = targetName:sub(1,1):upper() .. targetName:sub(2)

    local cachedData = _G.FikaTradeSkillCache and _G.FikaTradeSkillCache[targetName]
    if cachedData and cachedData.classFilename then
        local classColor = RAID_CLASS_COLORS[cachedData.classFilename]
        if classColor then return classColor.colorStr end
    end

    for i = 1, GetNumGuildMembers() do
        local fullName, _, _, _, _, _, _, _, _, _, classFilename = GetGuildRosterInfo(i)
        if fullName then
            local baseName = fullName:match("^([^%-]+)") or fullName
            baseName = baseName:gsub("%s+", ""):lower()
            baseName = baseName:sub(1,1):upper() .. baseName:sub(2)
            
            if baseName == targetName then
                if classFilename and RAID_CLASS_COLORS[classFilename] then
                    return classFilename and RAID_CLASS_COLORS[classFilename].colorStr or "9e9e9e"
                end
            end
        end
    end
    
    return "9e9e9e"
end

-- Helper to convert database role strings into matching texture asset targets
local function GetSpecIconTexture(specString)
    if not specString or specString == "" then return "" end
    
    local role = specString:match("^([^:]+)") or specString
    role = role:gsub("%s+", ""):lower()

    local filename = ""
    if role == "heal" or role == "healer" then
        filename = "Healer"
    elseif role == "tank" then
        filename = "Tank"
    elseif role == "dps" or role == "rdps" or role == "mdps" then
        filename = "DPS"
    end

    if filename == "" then return "" end
    return string.format("|TInterface\\AddOns\\Fika\\Textures\\%s.tga:16:16:0:0|t", filename)
end

-------------------------------------------------------------------
-- STRING MANIPULATION ENGINE (DISCORD BRIDGE ONLY)
-------------------------------------------------------------------
local function ParseDiscordMessage(text)
    if not text then return text, false end
    if not text:lower():match("kyparen") then return text, false end

    local pattern = "(|Hplayer:[^|]+|h)(.-)(|h[^:]*:%s*)%[([^%]]+)%]%s*:"

    local newText, matchCount = text:gsub(pattern, function(startLink, displayName, endLink, relayedSender)
        if not startLink:lower():match("kyparen") and not displayName:lower():match("kyparen") then
            return startLink .. displayName .. endLink .. "[" .. relayedSender .. "]:"
        end
        
        local useIcons = true
        if _G.FikaConfig and _G.FikaConfig.discordIcons == false then useIcons = false end
        
        local icon = ""
        local discordSuffix = ""
        
        if useIcons then
            icon = "|TInterface\\AddOns\\Fika\\Textures\\Discord.tga:14:14:0:0|t "
        else
            discordSuffix = " (Discord)"
        end
        
        relayedSender = relayedSender:match("^%s*(.-)%s*$") or relayedSender
        
        local colorHex = GetGuildClassColorHex(relayedSender)
        if not colorHex or colorHex == "" then colorHex = "9e9e9e" end
        if #colorHex == 8 then colorHex = colorHex:sub(3) end
        if #colorHex ~= 6 then colorHex = "9e9e9e" end
        
        return string.format("%s[|cff%s%s|r]%s:", icon, colorHex, relayedSender, discordSuffix)
    end)

    return newText, matchCount > 0
end

-------------------------------------------------------------------
-- MAIN ADD MESSAGE HOOK
-------------------------------------------------------------------
local function FikaAddMessageHook(self, text, ...)
    if type(text) ~= "string" then return OriginalAddMessage[self](self, text, ...) end

    local config = _G.FikaConfig or {
        enableDiscord = true, discordIcons = true, enableGuildChat = true, 
        guildChatOnly = true, guildMainSpecIcon = true, guildOffSpecIcon = false, guildShowMainName = true
    }

    -- 1. Apply Discord parsing inline
    if config.enableDiscord then
        local modifiedText, wasChanged = ParseDiscordMessage(text)
        if wasChanged then
            text = modifiedText
        end
    end
    
    -- 2. Process chat enhancements uniformly
    if config.enableGuildChat then
        -- Bulletproof structural check using the raw link data we caught in the logs
        local isGuildOrOfficer = text:find("Hchannel:GUILD") or text:find("Hchannel:OFFICER") or text:find("Hchannel:Community")
        
        -- If limited to guild/officer chat, step out immediately if it's an external channel
        if config.guildChatOnly and not isGuildOrOfficer then
            return OriginalAddMessage[self](self, text, ...)
        end

        -- Extract pure name out of the player tag block
        local playerName = text:match("|Hplayer:([^:|%-]+)")
        
        if playerName then
            -- Normalize case tracking parameters
            playerName = playerName:gsub("%s+", ""):lower()
            playerName = playerName:sub(1,1):upper() .. playerName:sub(2)

            local cached = _G.FikaTradeSkillCache and _G.FikaTradeSkillCache[playerName]
            local mainName = cached and (cached.mainName or cached.main)
            
            local spec1Icon = config.guildMainSpecIcon and cached and GetSpecIconTexture(cached.spec1) or ""
            local spec2Icon = config.guildOffSpecIcon and cached and GetSpecIconTexture(cached.spec2) or ""
            
            local iconPrefix = ""
            if spec1Icon ~= "" or spec2Icon ~= "" then
                local s1 = spec1Icon ~= "" and spec1Icon or ""
                local s2 = spec2Icon ~= "" and spec2Icon or ""
                iconPrefix = s1 .. (s1 ~= "" and s2 ~= "" and "/" or "") .. s2
            end
            
            local mainSuffix = ""
            if config.guildShowMainName and mainName then
                mainName = mainName:gsub("%s+", ""):lower()
                mainName = mainName:sub(1,1):upper() .. mainName:sub(2)
                
                if mainName ~= playerName then
                    local mainColorHex = GetGuildClassColorHex(mainName)
                    if #mainColorHex == 8 then mainColorHex = mainColorHex:sub(3) end
                    mainSuffix = string.format(" (|cff%s%s|r)", mainColorHex, mainName)
                end
            end
            
            local colorHex = GetGuildClassColorHex(playerName)
            if #colorHex == 8 then colorHex = colorHex:sub(3) end

            -- Clean string matching targeting the structured player blocks we intercepted
            text = text:gsub("(|Hplayer:[^|]+|h%[.-%]|h)", function(fullPlayerLink)
                -- Isolate structural start and end tags safely
                local linkStart, innerText, linkEnd = fullPlayerLink:match("(|Hplayer:[^|]+|h)%[(.-)%](|h)")
                if not linkStart then return fullPlayerLink end
                
                -- Strip existing class color overrides inside the visible name string
                local cleanText = innerText:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", "")
                
                -- FIX: Remove trailing space from cleanIconPrefix to pull icons flush against brackets
                local cleanIconPrefix = iconPrefix ~= "" and iconPrefix or ""
                
                -- Reassemble perfectly: [Icon][LinkStart][Colorized Name][LinkEnd][Main Name Suffix]
                return string.format("%s%s[|cff%s%s|r]%s%s", 
                    cleanIconPrefix, linkStart, colorHex, cleanText, linkEnd, mainSuffix)
            end)
        end
    end
    
    return OriginalAddMessage[self](self, text, ...)
end
-------------------------------------------------------------------
-- INITIALIZATION & PEER VERSION CONTROL ENGINE
-------------------------------------------------------------------
local frame = CreateFrame("Frame")
frame:RegisterEvent("PLAYER_ENTERING_WORLD")
frame:RegisterEvent("CHAT_MSG_ADDON")

local hasWarnedOutdated = false

-- Initialize the testing session ignore table globally on the shared addon scope
addonTable.ignoredTestSenders = addonTable.ignoredTestSenders or {}

frame:SetScript("OnEvent", function(self, event, ...)
    if event == "PLAYER_ENTERING_WORLD" then
        for i = 1, NUM_CHAT_WINDOWS do
            local chatFrame = _G["ChatFrame" .. i]
            if chatFrame and chatFrame.AddMessage and not OriginalAddMessage[chatFrame] then
                OriginalAddMessage[chatFrame] = chatFrame.AddMessage
                chatFrame.AddMessage = FikaAddMessageHook
            end
        end
        
        if IsInGuild() then
            if RegisterAddonMessagePrefix then RegisterAddonMessagePrefix("Fika") end
            
            -- Schedule login version sync
            local delay = 2 + math.random() * 3
            pendingVersionBroadcast = C_Timer.NewTimer(delay, function()
                SendAddonMessage("Fika", "V:" .. addonTable.version, "GUILD")
                pendingVersionBroadcast = nil
            end)
        end

    elseif event == "CHAT_MSG_ADDON" then
        local prefix, message, channel, sender = ...
        if prefix ~= "Fika" or addonTable.networkDisabled then return end
        
        local myName = UnitName("player")
        sender = sender:match("^([^%-]+)") or sender
        if sender == myName then return end

        -- Drop network traffic completely if this user has been session-muted as a tester
        if addonTable.ignoredTestSenders[sender] then 
            return 
        end

        if message:match("^V:") then
            local remoteVersionStr = message:sub(3)
            
            -- Dev Test Build Isolation Protocol Rule
            if remoteVersionStr:match("^[Tt]") then
                local localVersion = addonTable.version or "0.2.0"
                -- SILENT IGNORING: Mute the tester in the background without printing anything to chat
                if not localVersion:match("^[Tt]") then
                    addonTable.ignoredTestSenders[sender] = true
                    return
                end
            end

            local localX, localY, localZ = ParseVersionString(addonTable.version)
            local remoteX, remoteY, remoteZ = ParseVersionString(remoteVersionStr)
            
            -- SMART SUPPRESSION: If someone else broadcasts a version >= ours, cancel our echo
            if remoteX > localX or (remoteX == localX and remoteY > localY) or (remoteX == localX and remoteY == localY and remoteZ >= localZ) then
                if pendingVersionBroadcast then
                    pendingVersionBroadcast:Cancel()
                    pendingVersionBroadcast = nil
                end
            end

            -- RULE A: MAJOR PROTOCOL MISMATCH (HARD NETWORK KILL-SWITCH)
            if remoteX > localX then
                addonTable.networkDisabled = true
                self:UnregisterEvent("CHAT_MSG_ADDON")
                
                print("|cffff0000[FIKA CRITICAL ERROR]|r Din version är kritiskt föråldrad! Kommunikationsprotokollet har ändrats.")
                print("|cffff0000[FIKA]|r Addon-nätverket har inaktiverats för att förhindra datakorruption. Uppdatera addonet omedelbart!")
                return
            end
            
            -- RULE B: MINOR FEATURE HORIZON (SOFT ALERT - COMPATIBLE BUT OUTDATED)
            if remoteX == localX and remoteY > localY and not hasWarnedOutdated then
                hasWarnedOutdated = true
                print("|cff00ccff[FIKA UPPDATERING]|r En nyare funktionell version finns tillgänglig (" .. remoteVersionStr .. "). Vissa nya funktioner kan saknas lokalt.")
                return
            end

            -- RULE C: PATCH / BUGFIX HORIZON (SOFT ALERT)
            if remoteX == localX and remoteY == localY and remoteZ > localZ and not hasWarnedOutdated then
                hasWarnedOutdated = true
                print("|cff00ccff[FIKA UPPDATERING]|r En nyare buggfix finns tillgänglig (" .. remoteVersionStr .. "). Du kan fortsätta använda addonet.")
                return
            end
        end
    end
end)