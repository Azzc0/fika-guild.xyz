local addonName, addonTable = ...

local profMeta = {
    { name = "Blacksmithing", icon = "Interface\\Icons\\Trade_Blacksmithing" },
    { name = "Alchemy", icon = "Interface\\Icons\\Trade_Alchemy" },
    { name = "Engineering", icon = "Interface\\Icons\\Trade_Engineering" },
    { name = "Enchanting", icon = "Interface\\Icons\\Trade_Engraving" },
    { name = "Leatherworking", icon = "Interface\\Icons\\Trade_Leatherworking" },
    { name = "Tailoring", icon = "Interface\\Icons\\Trade_Tailoring" },
    { name = "Jewelcrafting", icon = "Interface\\Icons\\INV_Misc_Gem_01" },
    { name = "Inscription", icon = "Interface\\Icons\\INV_Scroll_08" },
    { name = "Mining", icon = "Interface\\Icons\\Trade_Mining" },
    { name = "Herbalism", icon = "Interface\\Icons\\Spell_Nature_NatureTouchGrow" },
    { name = "Skinning", icon = "Interface\\Icons\\INV_Misc_Pelt_Wolf_01" },
    { name = "Cooking", icon = "Interface\\Icons\\INV_Misc_Food_15" },
    { name = "First Aid", icon = "Interface\\Icons\\INV_Misc_Bandage_15" },
    { name = "Fishing", icon = "Interface\\Icons\\Trade_Fishing" },
}

local aliasMap = {
    ["h"] = "Herbalism", ["herb"] = "Herbalism", ["herbalism"] = "Herbalism",
    ["m"] = "Mining", ["mine"] = "Mining", ["mining"] = "Mining",
    ["s"] = "Skinning", ["skin"] = "Skinning", ["skinning"] = "Skinning",
    ["bs"] = "Blacksmithing", ["blacksmithing"] = "Blacksmithing",
    ["alc"] = "Alchemy", ["alchemy"] = "Alchemy",
    ["eng"] = "Engineering", ["engineering"] = "Engineering",
    ["ench"] = "Enchanting", ["enchanting"] = "Enchanting",
    ["lw"] = "Leatherworking", ["leatherworking"] = "Leatherworking",
    ["tailor"] = "Tailoring", ["tailoring"] = "Tailoring",
    ["jc"] = "Jewelcrafting", ["jewelcrafting"] = "Jewelcrafting",
    ["insc"] = "Inscription", ["inscription"] = "Inscription",
    ["cook"] = "Cooking", ["cooking"] = "Cooking",
    ["fa"] = "First Aid", ["first aid"] = "First Aid",
    ["fish"] = "Fishing", ["fishing"] = "Fishing"
}

local lastQueryTarget = ""
local lastQueryTime = 0

-------------------------------------------------------------------
-- 1. AUTOMATED MESH SYNC HOOKS
-------------------------------------------------------------------
local function AutoTriggerBankSync()
    local currentTab = GetCurrentGuildBankTab()
    if not currentTab or currentTab == 0 then return end
    
    -- Defer to Scanner.lua to build the multi-chunk payload array
    if addonTable.ScanCurrentTab then
        local syncPayloads = addonTable:ScanCurrentTab()
        
        if syncPayloads then
            -- Loop over the array chunks and send them over the wire
            for _, payload in ipairs(syncPayloads) do
                if payload and payload ~= "" then
                    SendAddonMessage("Fika", payload, "GUILD")
                end
            end
        end
    end
end

-- Safely handle Load-on-Demand sequence for the Guild Bank UI
local bankFrameHook = CreateFrame("Frame")
bankFrameHook:RegisterEvent("ADDON_LOADED")
bankFrameHook:SetScript("OnEvent", function(self, event, addon)
    if addon == "Blizzard_GuildBankUI" then
        -- Hook Blizzard's frame update so clicking tabs triggers the broadcast
        hooksecurefunc("GuildBankFrame_Update", AutoTriggerBankSync)
        self:UnregisterEvent("ADDON_LOADED")
    end
end)
-------------------------------------------------------------------
-- 2. PANEL HOOKS & SETUP
-------------------------------------------------------------------
local companionFrame = CreateFrame("Frame", "FikaGuildProfessionsDetailFrame", GuildMemberDetailFrame)
companionFrame:SetWidth(212)
companionFrame:SetHeight(185)
companionFrame:SetPoint("TOPLEFT", GuildMemberDetailFrame, "BOTTOMLEFT", 0, -2)
companionFrame:SetBackdrop({
    bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background", edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
    tile = true, tileSize = 32, edgeSize = 16, insets = { left = 5, right = 5, top = 5, bottom = 5 }
})

local mainNameTitle = companionFrame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
mainNameTitle:SetPoint("TOPLEFT", companionFrame, "TOPLEFT", 12, -14)
mainNameTitle:SetText("Main:")

local specTitle = companionFrame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
specTitle:SetPoint("TOPLEFT", companionFrame, "TOPLEFT", 12, -36)
specTitle:SetText("Specs:")

local rows, specRows = {}, {}
local mainNameFrame = nil
local targetCharacterName = nil
local isUpdatingUI = false

local dropdownMenuFrame = CreateFrame("Frame", "FikaSpecDropdownMenu", companionFrame, "UIDropDownMenuTemplate")

local function PlayerHasEditPermissions(target)
    if not target then return false end
    if CanEditOfficerNote() then return true end
    local localPlayer = UnitName("player")
    if localPlayer == target then return true end
    _G.FikaTradeSkillCache = _G.FikaTradeSkillCache or {}
    local targetData = _G.FikaTradeSkillCache[target]
    if targetData and targetData["main"] and targetData["main"] == localPlayer then return true end
    return false
end

local function TryInjectLinkToActiveField(link)
    if not link then return false end
    for i = 1, 5 do
        local row = rows[i]
        if row and row.editBox and row.editBox:HasFocus() then
            row.editBox:SetText(link)
            return true
        end
    end
    return false
end

-- Two-level nested dropdown setup matching SpecsData.lua structures
local function InitializeSpecDropdownMenu(self, level)
    if not targetCharacterName then return end
    level = level or 1
    
    local activeSlotIndex = dropdownMenuFrame.activeSlotIndex

    -- LEVEL 1: List Specialization Trees
    if level == 1 then
        local targetClassToken = nil
        local currentSelectionIndex = GetGuildRosterSelection()
        if currentSelectionIndex > 0 then
            local _, _, _, _, _, _, _, _, _, _, classFileName = GetGuildRosterInfo(currentSelectionIndex)
            targetClassToken = classFileName
        end

        local classTrees = addonTable.ClassSpecsDatabase[targetClassToken or ""]
        if not classTrees then return end

        for _, treeData in ipairs(classTrees) do
            local info = UIDropDownMenu_CreateInfo()
            info.text = treeData.name
            info.value = treeData 
            
            if treeData.roles and #treeData.roles > 1 then
                info.hasArrow = true
                info.notCheckable = true
            else
                local defaultRoleId = treeData.roles and treeData.roles[1] or "dps"
                local roleData = addonTable.Roles[defaultRoleId]
                info.icon = roleData and roleData.icon or nil
                info.func = function()
                    local compositeSpecString = defaultRoleId .. ":" .. treeData.id
                    _G.FikaTradeSkillCache = _G.FikaTradeSkillCache or {}
                    _G.FikaTradeSkillCache[targetCharacterName] = _G.FikaTradeSkillCache[targetCharacterName] or {}
                    _G.FikaTradeSkillCache[targetCharacterName]["spec" .. activeSlotIndex] = compositeSpecString
                    
                    addonTable:UpdateMemberProfessionsDisplay()
                    if addonTable.BroadcastSlotUpdate then
                        addonTable:BroadcastSlotUpdate(targetCharacterName, "spec" .. activeSlotIndex, compositeSpecString)
                    end
                    CloseDropDownMenus()
                end
            end
            UIDropDownMenu_AddButton(info, level)
        end

        -- Adjusted localized text to Swedish "Ta bort"
        local clearInfo = UIDropDownMenu_CreateInfo()
        clearInfo.text = "|cffcc3333Ta bort|r"
        clearInfo.func = function()
            _G.FikaTradeSkillCache = _G.FikaTradeSkillCache or {}
            if _G.FikaTradeSkillCache[targetCharacterName] then
                _G.FikaTradeSkillCache[targetCharacterName]["spec" .. activeSlotIndex] = nil
            end
            addonTable:UpdateMemberProfessionsDisplay()
            if addonTable.BroadcastSlotUpdate then
                addonTable:BroadcastSlotUpdate(targetCharacterName, "spec" .. activeSlotIndex, "EMPTY")
            end
            CloseDropDownMenus()
        end
        UIDropDownMenu_AddButton(clearInfo, level)

    -- LEVEL 2: Multi-Role Context Selection
    elseif level == 2 then
        local parentTreeData = UIDROPDOWNMENU_MENU_VALUE
        if not parentTreeData or not parentTreeData.roles then return end

        for _, roleId in ipairs(parentTreeData.roles) do
            local roleData = addonTable.Roles[roleId]
            local info = UIDropDownMenu_CreateInfo()
            
            info.text = parentTreeData.name .. " (" .. (roleData and roleData.name or roleId) .. ")"
            info.icon = roleData and roleData.icon or nil
            info.func = function()
                local compositeSpecString = roleId .. ":" .. parentTreeData.id
                _G.FikaTradeSkillCache = _G.FikaTradeSkillCache or {}
                _G.FikaTradeSkillCache[targetCharacterName] = _G.FikaTradeSkillCache[targetCharacterName] or {}
                _G.FikaTradeSkillCache[targetCharacterName]["spec" .. activeSlotIndex] = compositeSpecString
                
                addonTable:UpdateMemberProfessionsDisplay()
                if addonTable.BroadcastSlotUpdate then
                    addonTable:BroadcastSlotUpdate(targetCharacterName, "spec" .. activeSlotIndex, compositeSpecString)
                end
                CloseDropDownMenus()
            end
            UIDropDownMenu_AddButton(info, level)
        end
    end
end

UIDropDownMenu_Initialize(dropdownMenuFrame, InitializeSpecDropdownMenu, "MENU")

function addonTable:UpdateMemberProfessionsDisplay(updaterTargetContext)
    if not targetCharacterName or (updaterTargetContext and updaterTargetContext ~= targetCharacterName) then return end
    
    isUpdatingUI = true
    _G.FikaTradeSkillCache = _G.FikaTradeSkillCache or {}
    local memberData = _G.FikaTradeSkillCache[targetCharacterName] or {}
    
    local canEdit = PlayerHasEditPermissions(targetCharacterName)
    local canEditMainName = canEdit or (UnitName("player") == targetCharacterName)

    local targetClassToken = nil
    local currentSelectionIndex = GetGuildRosterSelection()
    if currentSelectionIndex > 0 then
        local _, _, _, _, _, _, _, _, _, _, classFileName = GetGuildRosterInfo(currentSelectionIndex)
        targetClassToken = classFileName
    end

    mainNameFrame.editBox:Hide() mainNameFrame.text:Show() mainNameFrame.removeBtn:Hide()
    local savedMain = memberData["main"]
    if savedMain and savedMain ~= "" and savedMain ~= "EMPTY" then
        mainNameFrame.text:SetText("|cffffffff" .. savedMain .. "|r")
        if canEditMainName then mainNameFrame.removeBtn:Show() end
        mainNameFrame:SetScript("OnClick", nil)
    else
        mainNameFrame.text:SetText("|cff888888None|r")
        mainNameFrame:SetScript("OnClick", canEditMainName and function()
            mainNameFrame.text:Hide() mainNameFrame.editBox:Show()
            isUpdatingUI = true mainNameFrame.editBox:SetText("") isUpdatingUI = false
            mainNameFrame.editBox:SetFocus()
        end or nil)
    end

    for i = 1, 2 do
        local sRow = specRows[i]
        local savedSpecString = memberData["spec" .. i]

        local specInfo = addonTable.GetParsedSpec and addonTable:GetParsedSpec(savedSpecString, targetClassToken) or nil
        if specInfo then
            sRow.icon:SetTexture(specInfo.roleIcon) 
            sRow.text:SetText("|cffffffff" .. specInfo.displayName .. "|r")
        else
            sRow.icon:SetTexture("Interface\\Icons\\INV_Misc_QuestionMark")
            sRow.text:SetText(i == 1 and "|cff888888MS|r" or "|cff888888OS|r")
        end

        sRow:SetScript("OnClick", canEdit and function()
            dropdownMenuFrame.activeSlotIndex = i
            ToggleDropDownMenu(1, nil, dropdownMenuFrame, sRow, 0, 0)
        end or nil)
    end

    local slots = { "1", "2", "3", "4", "5" }
    local labelFallbacks = { "Primary 1", "Primary 2", "First Aid", "Cooking", "Fishing" }

    for i = 1, 5 do
        local row = rows[i]
        local slotType = slots[i]
        local slotData = memberData[slotType]
        local savedLink = slotData and slotData.link

        if slotType == "3" then row.icon:SetTexture("Interface\\Icons\\INV_Misc_Bandage_15")
        elseif slotType == "4" then row.icon:SetTexture("Interface\\Icons\\INV_Misc_Food_15")
        elseif slotType == "5" then row.icon:SetTexture("Interface\\Icons\\Trade_Fishing")
        else
            row.icon:SetTexture("Interface\\Icons\\INV_Misc_QuestionMark")
        end

        row.removeBtn:Hide() row.editBox:Hide() row.text:Show()

        if slotData and (savedLink or (slotData.name and slotData.name ~= "EMPTY")) then
            local displayName = slotData.name or "Unknown"

            if savedLink then
                local cleanName = savedLink:match("%[([^%]]+)%]")
                if cleanName then displayName = cleanName:match("^([^:]+)") or cleanName end
            end

            if slotType == "1" or slotType == "2" then
                for _, data in ipairs(profMeta) do
                    if data.name:lower() == displayName:lower() then row.icon:SetTexture(data.icon) break end
                end
            end

            local textDisplayStr = savedLink or ("|cffffd100" .. displayName .. "|r")
            if slotData.level and slotData.level > 0 then
                textDisplayStr = textDisplayStr .. string.format(" |cff00ff00(%d/%d)|r", slotData.level, slotData.max or 450)
            end

            row.text:SetText(textDisplayStr)
            row:SetScript("OnClick", function()
                if IsShiftKeyDown() and savedLink and ChatFrame1EditBox:IsShown() then
                    ChatFrame1EditBox:Insert(savedLink)
                elseif savedLink then
                    local linkData = savedLink:match("|H([^|]+)|h")
                    if linkData then SetItemRef(linkData, savedLink, "LeftButton") end
                end
            end)
            if canEdit then row.removeBtn:Show() end
        else
            row.text:SetText("|cff888888" .. labelFallbacks[i] .. ": Empty|r")
            row:SetScript("OnClick", canEdit and function()
                row.text:Hide() row.editBox:Show()
                isUpdatingUI = true row.editBox:SetText("") isUpdatingUI = false
                row.editBox:SetFocus()
            end or nil)
        end
    end
    isUpdatingUI = false
end

mainNameFrame = CreateFrame("Button", nil, companionFrame)
mainNameFrame:SetSize(145, 18)
mainNameFrame:SetPoint("TOPLEFT", companionFrame, "TOPLEFT", 50, -11)
mainNameFrame.text = mainNameFrame:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
mainNameFrame.text:SetPoint("LEFT", mainNameFrame, "LEFT", 2, 0)
mainNameFrame.editBox = CreateFrame("EditBox", nil, mainNameFrame)
mainNameFrame.editBox:SetSize(115, 16)
mainNameFrame.editBox:SetPoint("LEFT", mainNameFrame, "LEFT", 2, 0)
mainNameFrame.editBox:SetFontObject("GameFontHighlightSmall")
mainNameFrame.editBox:SetAutoFocus(false)
mainNameFrame.editBox:Hide()

mainNameFrame.editBox:SetScript("OnEnterPressed", function(self)
    local text = self:GetText()
    if text and text ~= "" and targetCharacterName then
        _G.FikaTradeSkillCache = _G.FikaTradeSkillCache or {}
        _G.FikaTradeSkillCache[targetCharacterName] = _G.FikaTradeSkillCache[targetCharacterName] or {}
        _G.FikaTradeSkillCache[targetCharacterName]["main"] = text
        self:Hide() self:ClearFocus()
        addonTable:UpdateMemberProfessionsDisplay()
        if addonTable.BroadcastSlotUpdate then
            addonTable:BroadcastSlotUpdate(targetCharacterName, "main", text)
        end
    else self:Hide() self:ClearFocus() end
end)
mainNameFrame.editBox:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
mainNameFrame.editBox:SetScript("OnEditFocusLost", function(self) self:Hide() addonTable:UpdateMemberProfessionsDisplay() end)

mainNameFrame.removeBtn = CreateFrame("Button", nil, mainNameFrame, "UIPanelCloseButton")
mainNameFrame.removeBtn:SetSize(14, 14)
mainNameFrame.removeBtn:SetPoint("LEFT", mainNameFrame.text, "RIGHT", 2, 0)
mainNameFrame.removeBtn:SetScript("OnClick", function()
    if targetCharacterName and _G.FikaTradeSkillCache[targetCharacterName] then
        _G.FikaTradeSkillCache[targetCharacterName]["main"] = nil
        addonTable:UpdateMemberProfessionsDisplay()
        if addonTable.BroadcastSlotUpdate then
            addonTable:BroadcastSlotUpdate(targetCharacterName, "main", "EMPTY")
        end
    end
end)

for i = 1, 2 do
    local row = CreateFrame("Button", nil, companionFrame)
    row:SetSize(72, 18)
    row:SetPoint("TOPLEFT", companionFrame, "TOPLEFT", 50 + ((i - 1) * 78), -33)
    
    row.icon = row:CreateTexture(nil, "BACKGROUND")
    row.icon:SetSize(14, 14)
    row.icon:SetPoint("LEFT", row, "LEFT", 0, 0)
    
    row.text = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    row.text:SetPoint("LEFT", row.icon, "RIGHT", 4, 0)
    row.text:SetWidth(64)
    row.text:SetJustifyH("LEFT")
    
    specRows[i] = row
end

local slots = { "1", "2", "3", "4", "5" }
for i = 1, 5 do
    local row = CreateFrame("Button", nil, companionFrame)
    row:SetSize(192, 20)
    row:SetPoint("TOPLEFT", companionFrame, "TOPLEFT", 10, -60 - ((i - 1) * 22))
    row.icon = row:CreateTexture(nil, "BACKGROUND")
    row.icon:SetSize(16, 16)
    row.icon:SetPoint("LEFT", row, "LEFT", 2, 0)
    row.text = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    row.text:SetPoint("LEFT", row.icon, "RIGHT", 6, 0)
    
    local editBox = CreateFrame("EditBox", nil, row)
    editBox:SetSize(150, 18)
    editBox:SetPoint("LEFT", row.icon, "RIGHT", 4, 0)
    editBox:SetFontObject("GameFontHighlightSmall")
    editBox:SetAutoFocus(false)
    editBox:Hide()
    
    editBox:SetScript("OnTextChanged", function(self)
        if isUpdatingUI then return end
        local text = self:GetText()
        if text and text ~= "" and targetCharacterName then
            local isTrade, isSpell = text:find("|Htrade:") or text:find("|Hspell:")
            if isTrade or isSpell then
                local cleanName = text:match("%[([^%]]+)%]") or "Unknown"
                local resolvedProfName = cleanName:match("^([^:]+)") or cleanName
                
                local parentRow = self:GetParent()
                local determinedSlot = parentRow.slotID
                
                if determinedSlot == "3" and not resolvedProfName:lower():find("first") then return end
                if determinedSlot == "4" and not resolvedProfName:lower():find("cook") then return end
                if determinedSlot == "5" then resolvedProfName = "Fishing" end

                if determinedSlot == "1" or determinedSlot == "2" then
                    if resolvedProfName == "First Aid" then determinedSlot = "3"
                    elseif resolvedProfName == "Cooking" then determinedSlot = "4"
                    elseif resolvedProfName == "Fishing" then determinedSlot = "5"
                    else
                        _G.FikaTradeSkillCache = _G.FikaTradeSkillCache or {}
                        local currentData = _G.FikaTradeSkillCache[targetCharacterName] or {}
                        if parentRow.slotID == "2" or (currentData["1"] and currentData["1"].name ~= resolvedProfName) then 
                            determinedSlot = "2" 
                        end
                    end
                end

                _G.FikaTradeSkillCache = _G.FikaTradeSkillCache or {}
                _G.FikaTradeSkillCache[targetCharacterName] = _G.FikaTradeSkillCache[targetCharacterName] or {}
                
                local pLevel, pMax = 0, 450
                local lLevel, lMax = text:match("|Htrade:%d+:(%d+):(%d+):")
                if lLevel and lMax then pLevel = tonumber(lLevel) or 0 pMax = tonumber(lMax) or 450 end

                _G.FikaTradeSkillCache[targetCharacterName][determinedSlot] = {
                    link = text, name = resolvedProfName, level = pLevel, max = pMax, timestamp = time()
                }
                self:Hide() self:ClearFocus()
                addonTable:UpdateMemberProfessionsDisplay()
                if addonTable.BroadcastSlotUpdate then
                    addonTable:BroadcastSlotUpdate(targetCharacterName, determinedSlot, text)
                end
            end
        end
    end)
    
    editBox:SetScript("OnEnterPressed", function(self)
        if isUpdatingUI then return end
        local text = self:GetText()
        if text and text ~= "" and targetCharacterName then
            local parentRow = self:GetParent()
            local defaultSlot = parentRow.slotID
            
            _G.FikaTradeSkillCache = _G.FikaTradeSkillCache or {}
            _G.FikaTradeSkillCache[targetCharacterName] = _G.FikaTradeSkillCache[targetCharacterName] or {}
            local currentData = _G.FikaTradeSkillCache[targetCharacterName]
            
            local cleanText = text:lower():gsub("^%s*(.-)%s*$", "%1")
            
            local aliasPart, curLevel, maxLevel = cleanText:match("^([a-z%s]+)%s+(%d+)/(%d+)")
            if not aliasPart then aliasPart, curLevel = cleanText:match("^([a-z%s]+)%s+(%d+)") end
            if not aliasPart then aliasPart = cleanText:match("^([a-z%s]+)$") end
            
            curLevel = tonumber(curLevel) or 0
            maxLevel = tonumber(maxLevel) or 450
            
            local resolvedName = aliasMap[aliasPart or ""] or text
            
            if defaultSlot == "3" and not cleanText:find("first") and not cleanText:find("aid") then self:Hide() self:ClearFocus() return end
            if defaultSlot == "4" and not cleanText:find("cook") then self:Hide() self:ClearFocus() return end
            if defaultSlot == "5" then resolvedName = "Fishing" end
            
            local targetSlot = defaultSlot
            if defaultSlot == "1" or defaultSlot == "2" then
                if resolvedName == "First Aid" then targetSlot = "3"
                elseif resolvedName == "Cooking" then targetSlot = "4"
                elseif resolvedName == "Fishing" then targetSlot = "5"
                else
                    if defaultSlot == "2" or (currentData["1"] and currentData["1"].name ~= resolvedName) then 
                        targetSlot = "2" 
                    else 
                        targetSlot = "1" 
                    end
                end
            end

            _G.FikaTradeSkillCache[targetCharacterName][targetSlot] = {
                link = nil, name = resolvedName, level = curLevel, max = maxLevel, timestamp = time()
            }
            self:Hide() self:ClearFocus()
            addonTable:UpdateMemberProfessionsDisplay()
            
            local manualWireValue = string.format("%d:%d:%s", curLevel, maxLevel, resolvedName)
            if addonTable.BroadcastSlotUpdate then
                addonTable:BroadcastSlotUpdate(targetCharacterName, targetSlot, manualWireValue)
            end
        else self:Hide() self:ClearFocus() end
    end)
    editBox:SetScript("OnEditFocusLost", function(self) self:Hide() addonTable:UpdateMemberProfessionsDisplay() end)
    editBox:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
    
    row.editBox = editBox
    row.slotID = slots[i] 
    
    row.removeBtn = CreateFrame("Button", nil, row, "UIPanelCloseButton")
    row.removeBtn:SetSize(16, 16)
    row.removeBtn:SetPoint("RIGHT", row, "RIGHT", -2, 0)
    row.removeBtn:SetScript("OnClick", function(btn)
        local parentRow = btn:GetParent()
        if targetCharacterName and _G.FikaTradeSkillCache[targetCharacterName] and parentRow.slotID then
            _G.FikaTradeSkillCache[targetCharacterName][parentRow.slotID] = nil
            addonTable:UpdateMemberProfessionsDisplay()
            if addonTable.BroadcastSlotUpdate then
                addonTable:BroadcastSlotUpdate(targetCharacterName, parentRow.slotID, "EMPTY")
            end
        end
    end)
    rows[i] = row
end

local function SyncUIDisplayToSelectedMember()
    if not GuildMemberDetailFrame:IsShown() then return end
    local name = GetGuildRosterInfo(GetGuildRosterSelection())
    if name and name ~= "" then
        companionFrame:Show()
        targetCharacterName = name
        
        local cleanName = name:lower()
        local currentTime = debugprofilestop()
        if (cleanName ~= lastQueryTarget or (currentTime - lastQueryTime) > 2000) and (currentTime - lastQueryTime) > 100 then
            lastQueryTime = currentTime
            lastQueryTarget = cleanName
            -- SendAddonMessage("Fika", "Q:" .. name, "GUILD")
            if _G.Fika and _G.Fika.SendSafeQuery then
                _G.Fika:SendSafeQuery(name)
            end
        end

        addonTable:UpdateMemberProfessionsDisplay()
    end
end

GuildMemberDetailFrame:HookScript("OnShow", SyncUIDisplayToSelectedMember)
hooksecurefunc("GuildStatus_Update", SyncUIDisplayToSelectedMember)

GuildMemberDetailFrame:HookScript("OnHide", function() 
    companionFrame:Hide() 
end)

local originalChatEdit_InsertLink = ChatEdit_InsertLink
---@diagnostic disable-next-line: duplicate-set-field
function ChatEdit_InsertLink(link)
    if TryInjectLinkToActiveField(link) then return true end
    return originalChatEdit_InsertLink(link)
end

hooksecurefunc("HandleModifiedItemClick", function(link)
    if link and (link:find("|Htrade:") or link:find("|Hspell:")) then
        TryInjectLinkToActiveField(link)
    end
end)

local tradeSkillFrameHook = CreateFrame("Frame")
tradeSkillFrameHook:RegisterEvent("ADDON_LOADED")
tradeSkillFrameHook:SetScript("OnEvent", function(self, event, addon)
    if addon == "Blizzard_TradeSkillUI" then
        if TradeSkillFrameShareButton then
            TradeSkillFrameShareButton:SetScript("PreClick", function()
                local link = GetTradeSkillListLink()
                for i = 1, 5 do
                    if rows[i] and rows[i].editBox and rows[i].editBox:HasFocus() then
                        if link then
                            rows[i].editBox:SetText(link)
                            local onTextChanged = rows[i].editBox:GetScript("OnTextChanged")
                            if onTextChanged then onTextChanged(rows[i].editBox) end
                        end
                        return 
                    end
                end
            end)
        end
        hooksecurefunc("TradeSkillFrame_SetSelection", function(id)
            if IsShiftKeyDown() then
                local link = GetTradeSkillListLink()
                if link then
                    TryInjectLinkToActiveField(link)
                end
            end
        end)
        self:UnregisterEvent("ADDON_LOADED")
    end
end)

-------------------------------------------------------------------
-- 4. PASSIVE CLASS CACHE SYNCER
-------------------------------------------------------------------
local function SyncGuildClassesToCache()
    if not _G.FikaTradeSkillCache then return end
    
    local totalMembers = GetNumGuildMembers()
    if totalMembers == 0 then return end
    
    -- Passive iteration over the active client roster state
    for i = 1, totalMembers do
        local fullName, _, _, _, _, _, _, _, _, _, classFilename = GetGuildRosterInfo(i)
        if fullName and classFilename then
            -- Strip trailing dashes safely
            local baseName = fullName:match("^([^%-]+)") or fullName
            
            -- If they already exist in your professions cache, bind their class information
            if _G.FikaTradeSkillCache[baseName] then
                _G.FikaTradeSkillCache[baseName].classFilename = classFilename
            else
                -- Seeds missing alts passively so their names can colorize without profile records
                _G.FikaTradeSkillCache[baseName] = { classFilename = classFilename }
            end
        end
    end
end

local syncFrame = CreateFrame("Frame")
syncFrame:RegisterEvent("GUILD_ROSTER_UPDATE")
syncFrame:SetScript("OnEvent", function(self, event)
    SyncGuildClassesToCache()
end)