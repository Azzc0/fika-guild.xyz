local addonName, addonTable = ...

-- Automatically calculate the base directory path of your addon
local addonFolder = "Interface\\AddOns\\" .. addonName .. "\\Textures\\"

addonTable.Roles = {
    ["tank"] = { name = "Tank", icon = addonFolder .. "Tank.tga" },
    ["heal"] = { name = "Healer", icon = addonFolder .. "Healer.tga" },
    ["dps"]  = { name = "DPS", icon = addonFolder .. "DPS.tga" },
    ["rdps"] = { name = "DPS", icon = addonFolder .. "DPS.tga" },
    ["mdps"] = { name = "DPS", icon = addonFolder .. "DPS.tga" }
}

-- Inverted Database: Tree selection dictates allowed roles
addonTable.ClassSpecsDatabase = {
    WARRIOR = {
        { id = "arms",       name = "Arms",       roles = { "dps", "tank" } },
        { id = "fury",       name = "Fury",       roles = { "dps" } },
        { id = "protection", name = "Protection", roles = { "tank" } }
    },
    PALADIN = {
        { id = "holy",       name = "Holy",       roles = { "heal" } },
        { id = "protection", name = "Protection", roles = { "tank" } },
        { id = "retribution",name = "Retribution",roles = { "dps" } }
    },
    ROGUE = {
        { id = "assassination", name = "Assassination", roles = { "dps" } },
        { id = "combat",        name = "Combat",        roles = { "dps" } },
        { id = "subtlety",      name = "Subtlety",      roles = { "dps" } }
    },
    PRIEST = {
        { id = "discipline", name = "Discipline", roles = { "heal" } },
        { id = "holy",       name = "Holy",       roles = { "heal" } },
        { id = "shadow",     name = "Shadow",     roles = { "dps" } }
    },
    DEATHKNIGHT = {
        { id = "blood",  name = "Blood",  roles = { "tank", "dps" } },
        { id = "frost",  name = "Frost",  roles = { "tank", "dps" } },
        { id = "unholy", name = "Unholy", roles = { "dps" } }
    },
    SHAMAN = {
        { id = "elemental",   name = "Elemental",   roles = { "dps" } },
        { id = "enhancement", name = "Enhancement", roles = { "dps" } },
        { id = "restoration", name = "Restoration", roles = { "heal" } }
    },
    MAGE = {
        { id = "arcane", name = "Arcane", roles = { "dps" } },
        { id = "fire",   name = "Fire",   roles = { "dps" } },
        { id = "frost",  name = "Frost",  roles = { "dps" } }
    },
    WARLOCK = {
        { id = "affliction",  name = "Affliction",  roles = { "dps" } },
        { id = "demonology",  name = "Demonology",  roles = { "dps" } },
        { id = "destruction", name = "Destruction", roles = { "dps" } }
    },
    DRUID = {
        { id = "balance",     name = "Balance",     roles = { "dps" } },
        { id = "feral",       name = "Feral",       roles = { "tank", "dps" } },
        { id = "restoration", name = "Restoration", roles = { "heal" } }
    },
    HUNTER = {
        { id = "beastmastery", name = "Beast Mastery", roles = { "dps" } },
        { id = "marksmanship",  name = "Marksmanship",  roles = { "dps" } },
        { id = "survival",      name = "Survival",      roles = { "dps"} }
    },
}

-- Parses "role:tree" to display [Role Icon] [Formatted Tree Affix Name]
function addonTable:GetParsedSpec(savedString, classToken)
    if not savedString or savedString == "" or savedString == "Empty" then return nil end
    
    local roleId, treeId = savedString:match("^([^:]+):([^:]+)$")
    if not roleId or not treeId then return nil end
    
    local roleData = addonTable.Roles[roleId]
    if not roleData then return nil end

    -- Find matching human-readable tree display string from database layout
    local displayTreeName = treeId:gsub("^%l", string.upper)
    local classTrees = addonTable.ClassSpecsDatabase[classToken or ""]
    if classTrees then
        for _, treeData in ipairs(classTrees) do
            if treeData.id == treeId then
                displayTreeName = treeData.name
                break
            end
        end
    end
    
    return {
        roleIcon = roleData.icon,
        displayName = displayTreeName
    }
end