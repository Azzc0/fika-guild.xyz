local addonName, addonTable = ...

local chars = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"

local function ToBase36(num, length)
    local str = ""
    if num == 0 then str = "0" end
    while num > 0 do
        local remainder = (num % 36) + 1
        str = string.sub(chars, remainder, remainder) .. str
        num = math.floor(num / 36)
    end
    return string.rep("0", length - #str) .. str
end

local function ScanSlotRange(currentTab, startSlot, endSlot)
    local tabData = {}
    for slot = startSlot, endSlot do
        local _, count, _ = GetGuildBankItemInfo(currentTab, slot)
        local itemLink = GetGuildBankItemLink(currentTab, slot)
        
        if itemLink and count and count > 0 then
            local itemID = tonumber(itemLink:match("item:(%d+):")) or 0
            if itemID > 0 then
                local slotStr = ToBase36(slot, 2)
                local idStr = ToBase36(itemID, 4)
                local countStr = ToBase36(count, 2)
                table.insert(tabData, slotStr .. idStr .. countStr)
            end
        end
    end
    return #tabData > 0 and table.concat(tabData, "") or "EMPTY"
end

function addonTable:ScanCurrentTab()
    local currentTab = GetCurrentGuildBankTab()
    if not currentTab or currentTab == 0 then return nil end

    local payloads = {}
    
    -- 1. Global Gold Balance Plain Integer Packet
    local totalMoney = GetGuildBankMoney() or 0
    table.insert(payloads, "GBS:0:" .. totalMoney)

    -- 2. Metadata String Header Configuration Packet
    local metaTab = currentTab * 10
    local tabName, tabIcon = GetGuildBankTabInfo(currentTab)
    tabName = tabName or ("Tab " .. currentTab)
    local cleanIcon = tabIcon and tabIcon:match("([^ll\\]+)$") or "INV_Misc_QuestionMark"
    local scanTime = time() 
    
    local metaPayload = string.format("GBS:%d:%s:%s:%d", metaTab, tabName, cleanIcon, scanTime)
    table.insert(payloads, metaPayload)

    -- 3. Chunked Base-36 Item Snapshots
    local ranges = {
        { part = 1, start = 1,  stop = 25 },
        { part = 2, start = 26, stop = 50 },
        { part = 3, start = 51, stop = 75 },
        { part = 4, start = 76, stop = 98 }
    }
    
    for _, r in ipairs(ranges) do
        local virtualTab = (currentTab * 10) + r.part
        local chunkData = ScanSlotRange(currentTab, r.start, r.stop)
        table.insert(payloads, "GBS:" .. virtualTab .. ":" .. chunkData)
    end
    
    return payloads
end

function addonTable:GetSlotForProfession(charName, profName)
    if profName == "First Aid" then return "3"
    elseif profName == "Cooking" then return "4"
    elseif profName == "Fishing" then return "5"
    end
    
    _G.FikaTradeSkillCache = _G.FikaTradeSkillCache or {}
    _G.FikaTradeSkillCache[charName] = _G.FikaTradeSkillCache[charName] or {}
    local data = _G.FikaTradeSkillCache[charName]
    
    if data["1"] and (data["1"].name == profName or (data["1"].link and data["1"].link:find(profName))) then
        return "1"
    elseif data["2"] and (data["2"].name == profName or (data["2"].link and data["2"].link:find(profName))) then
        return "2"
    elseif not data["1"] then
        return "1"
    else
        return "2"
    end
end