local addonName, addonTable = ...
_G.Fika = addonTable

_G.FikaTradeSkillCache = _G.FikaTradeSkillCache or {}

local Frame = CreateFrame("Frame")
Frame:RegisterEvent("ADDON_LOADED")
Frame:RegisterEvent("CHAT_MSG_ADDON")

-------------------------------------------------------------------
-- OUTBOUND PIPELINE
-------------------------------------------------------------------
function addonTable:SendSafeQuery(targetCharacter)
    if addonTable.networkDisabled or not targetCharacter then return end
    
    -- Normalize string: Strip realm extensions ("Player-Realm" -> "Player")
    local cleanName = targetCharacter:match("^([^%-]+)") or targetCharacter
    
    -- Leverage the central Core tracking to block redundant spam
    if addonTable:IsCharacterOnCooldown(cleanName) then
        -- Action blocked: A query or response occurred within the last 90 seconds.
        return 
    end
    
    -- Mark cooldown locally immediately to throttle fast frame toggles
    addonTable:SetCharacterCooldown(cleanName)
    SendAddonMessage("Fika", "Q:" .. cleanName, "GUILD")
end

function addonTable:BroadcastSlotUpdate(targetCharacter, slotKey, value)
    if addonTable.networkDisabled then return end
    if not targetCharacter or not slotKey or not value then return end
    SendAddonMessage("Fika", string.format("U:%s:%s:%s", targetCharacter, slotKey, value), "GUILD")
end

function addonTable:BroadcastBankSync(payloads)
    if addonTable.networkDisabled then return end
    if not payloads or type(payloads) ~= "table" then return end
    for _, payload in ipairs(payloads) do
        if payload and payload ~= "" then
            SendAddonMessage("Fika", payload, "GUILD")
        end
    end
end

-------------------------------------------------------------------
-- INBOUND TRAFFIC INTERCEPTOR
-------------------------------------------------------------------
Frame:SetScript("OnEvent", function(self, event, ...)
    if event == "ADDON_LOADED" then
        local name = ...
        if name == addonName then
            if RegisterAddonMessagePrefix then RegisterAddonMessagePrefix("Fika") end
            self:UnregisterEvent("ADDON_LOADED")
        end
    elseif event == "CHAT_MSG_ADDON" then
        local prefix, msg, channel, sender = ...
        if prefix ~= "Fika" or addonTable.networkDisabled then return end

        local localPlayer = UnitName("player")
        -- Normalize incoming sender string to match localPlayer layout
        local senderName = sender:match("^([^%-]+)") or sender
        if senderName:lower() == localPlayer:lower() then return end

        -------------------------------------------------------------------
        -- 1. INBOUND QUERIES (Q:)
        -------------------------------------------------------------------
        local qTarget = msg:match("^Q:(.+)")
        if qTarget then
            -- Query processing is strictly handled by the external bot backend.
            return
        end

        -------------------------------------------------------------------
        -- 2. INBOUND REPLIES / LIVE CLIENT UPDATES (R: and U:)
        -------------------------------------------------------------------
        local action, rTarget, slotType, identifier = msg:match("^([^:]+):([^:]+):([^:]+):(.*)$")
        if (action == "R" or action == "U") and rTarget and slotType then
            _G.FikaTradeSkillCache[rTarget] = _G.FikaTradeSkillCache[rTarget] or {}
            
            if identifier:upper() == "EMPTY" then
                _G.FikaTradeSkillCache[rTarget][slotType] = nil
            elseif slotType == "main" or slotType == "spec1" or slotType == "spec2" then
                _G.FikaTradeSkillCache[rTarget][slotType] = identifier
            else
                local isLink = identifier:find("|H")
                local parsedLevel, parsedMax = 0, 450
                
                if isLink then
                    local linkLevel, linkMax = identifier:match("|Htrade:%d+:(%d+):(%d+):")
                    if linkLevel and linkMax then
                        parsedLevel = tonumber(linkLevel) or 0
                        parsedMax = tonumber(linkMax) or 450
                    end
                else
                    -- Fallback: Parse non-linked raw configurations strings ("450:450:Skinning")
                    local rawLevel, rawMax, rawName = identifier:match("^(%d+):(%d+):(.+)$")
                    if rawLevel and rawMax and rawName then
                        parsedLevel = tonumber(rawLevel) or 0
                        parsedMax = tonumber(rawMax) or 450
                        identifier = rawName
                    end
                end

                local cleanName = isLink and identifier:match("%[([^%]]+)%]") or identifier
                if cleanName then cleanName = cleanName:match("^([^:]+)") or cleanName end

                _G.FikaTradeSkillCache[rTarget][slotType] = {
                    link = isLink and identifier or nil,
                    name = cleanName or "Unknown",
                    level = parsedLevel,
                    max = parsedMax,
                    timestamp = time()
                }
            end
            
            if addonTable.UpdateMemberProfessionsDisplay then
                addonTable:UpdateMemberProfessionsDisplay(rTarget)
            end
            return
        end

        -------------------------------------------------------------------
        -- 3. INBOUND ORPHANED LIST UPDATES (QMR:)
        -------------------------------------------------------------------
        local qmrPayload = msg:match("^QMR:(.+)")
        if qmrPayload then
            if addonTable.UpdateOrphanedCharacters then
                if qmrPayload == "NONE" then
                    addonTable:UpdateOrphanedCharacters("")
                else
                    addonTable:UpdateOrphanedCharacters(qmrPayload)
                end
            end
            return
        end
    end
end)