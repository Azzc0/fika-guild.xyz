local addonName, addonTable = ...
_G.Fika = addonTable

-- Initialize structural global caches if they don't exist
_G.FikaTradeSkillCache = _G.FikaTradeSkillCache or {}
addonTable.antiSpamCooldowns = addonTable.antiSpamCooldowns or {
    chars = {},
    tabs = {}
}

-------------------------------------------------------------------
-- ANTI-SPAM HELPER COOLDOWN METHODS
-------------------------------------------------------------------
function addonTable:SetCharacterCooldown(charName)
    if not charName then return end
    addonTable.antiSpamCooldowns.chars[charName:lower()] = time()
end

function addonTable:IsCharacterOnCooldown(charName)
    if not charName then return false end
    local lastQuery = addonTable.antiSpamCooldowns.chars[charName:lower()] or 0
    return (time() - lastQuery) < 90
end

function addonTable:SetTabCooldown(tabId)
    if not tabId then return end
    addonTable.antiSpamCooldowns.tabs[tabId] = time()
end

function addonTable:IsTabOnCooldown(tabId)
    if not tabId then return false end
    local lastSync = addonTable.antiSpamCooldowns.tabs[tabId] or 0
    return (time() - lastSync) < 15
end

-------------------------------------------------------------------
-- EVENT DISPATCHER FRAME
-------------------------------------------------------------------
local Frame = CreateFrame("Frame")
Frame:RegisterEvent("ADDON_LOADED")
Frame:RegisterEvent("CHAT_MSG_ADDON")

Frame:SetScript("OnEvent", function(self, event, ...)
    if event == "ADDON_LOADED" then
        local name = ...
        if name == addonName then
            if C_ChatInfo and C_ChatInfo.RegisterAddonMessagePrefix then
                C_ChatInfo.RegisterAddonMessagePrefix("Fika")
            elseif RegisterAddonMessagePrefix then
                RegisterAddonMessagePrefix("Fika")
            end
            self:UnregisterEvent("ADDON_LOADED")
        end
    elseif event == "CHAT_MSG_ADDON" then
        local prefix, msg, channel, sender = ...
        if prefix ~= "Fika" or addonTable.networkDisabled then return end

        -------------------------------------------------------------------
        -- 1. SNOOPING OUTBOUND GUILD BANK TRAFFIC
        -------------------------------------------------------------------
        local gbsTab = msg:match("^GBS:(%d+):")
        if gbsTab then
            local tabId = math.floor(tonumber(gbsTab) / 10)
            if tabId > 0 then
                addonTable:SetTabCooldown(tabId)
            end
            return
        end

        -------------------------------------------------------------------
        -- 2. SHADOWING MESH RESPONSES & USER PUSHES (R: and U:)
        -------------------------------------------------------------------
        local action, rTarget, slotType, level, max, identifier = msg:match("^([^:]+):([^:]+):([^:]+):(%d+):(%d+):(.*)$")
        if (action == "R" or action == "U") and rTarget and slotType then
            addonTable:SetCharacterCooldown(rTarget)
        end

        -------------------------------------------------------------------
        -- 3. INBOUND INTERROGATION TRAFFIC (Queries)
        -------------------------------------------------------------------
        local qTarget = msg:match("^Q:(.+)")
        if qTarget then
            -- Purely track visual user cooldown frames; no automated client transmissions.
            addonTable:SetCharacterCooldown(qTarget)
            return
        end
    end
end)