local addonName, addonTable = ...

-- Automatically fetch version string from Fika.toc
local addonVersion = GetAddOnMetadata(addonName, "Version") or "1.0.0"

-- Define standard default options configuration layout
local defaultSettings = {
    enableDiscord = true,
    discordIcons = true,
    enableGuildChat = true,
    guildChatOnly = true,
    guildMainSpecIcon = true,
    guildOffSpecIcon = false,
    guildShowMainName = true,
}

local function InitializeFikaConfig()
    _G.FikaConfig = _G.FikaConfig or {}
    for key, defaultValue in pairs(defaultSettings) do
        if _G.FikaConfig[key] == nil then
            _G.FikaConfig[key] = defaultValue
        end
    end
end

-------------------------------------------------------------------
-- 1. ROOT FRAME SETUP (Unified Parent Panel)
-------------------------------------------------------------------
local rootPanel = CreateFrame("Frame", "FikaOptionsPanel", InterfaceOptionsFramePanelContainer)
rootPanel.name = "Fika"
InterfaceOptions_AddCategory(rootPanel)

-- Global Title: # Fika X.Y.Z
local title = rootPanel:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
title:SetPoint("TOPLEFT", 16, -16)
title:SetText("Fika Addon v" .. addonVersion)

-------------------------------------------------------------------
-- 2. VIEW CANVAS SEGMENTS (The Pages)
-------------------------------------------------------------------
-- Page 1: Main / Documentation / Admin
local mainView = CreateFrame("Frame", nil, rootPanel)
mainView:SetPoint("TOPLEFT", title, "BOTTOMLEFT", 0, -40)
mainView:SetPoint("BOTTOMRIGHT", rootPanel, "BOTTOMRIGHT", 0, 0)

-- Page 2: Chat Integration & Live Previews
local chatView = CreateFrame("Frame", nil, rootPanel)
chatView:SetPoint("TOPLEFT", title, "BOTTOMLEFT", 0, -40)
chatView:SetPoint("BOTTOMRIGHT", rootPanel, "BOTTOMRIGHT", 0, 0)
chatView:Hide()

-- Page 3: Changelog
local changelogView = CreateFrame("Frame", nil, rootPanel)
changelogView:SetPoint("TOPLEFT", title, "BOTTOMLEFT", 0, -40)
changelogView:SetPoint("BOTTOMRIGHT", rootPanel, "BOTTOMRIGHT", 0, 0)
changelogView:Hide()

local allViews = { mainView, chatView, changelogView }

local function SetActiveView(targetView)
    for _, view in ipairs(allViews) do
        if view == targetView then
            view:Show()
        else
            view:Hide()
        end
    end
end

-------------------------------------------------------------------
-- 3. UNIFIED TOP NAVIGATION TABS ([Main] [Chat] [Changelog])
-------------------------------------------------------------------
local function StyleTabButton(btn)
    btn:SetSize(95, 22)
    -- Borrowing the clean standard button look used in Questie/Blizzard sub-menus
    btn:SetNormalFontObject("GameFontNormalSmall")
    btn:SetHighlightFontObject("GameFontHighlightSmall")
end

local mainBtn = CreateFrame("Button", "FikaTabMain", rootPanel, "UIPanelButtonTemplate")
StyleTabButton(mainBtn)
mainBtn:SetPoint("LEFT", title, "RIGHT", 20, 0)
mainBtn:SetText("Main")
mainBtn:SetScript("OnClick", function() PlaySound("igMainMenuOptionCheckBoxOn") SetActiveView(mainView) end)

local chatBtn = CreateFrame("Button", "FikaTabChat", rootPanel, "UIPanelButtonTemplate")
StyleTabButton(chatBtn)
chatBtn:SetPoint("LEFT", mainBtn, "RIGHT", 4, 0)
chatBtn:SetText("Chat")
chatBtn:SetScript("OnClick", function() PlaySound("igMainMenuOptionCheckBoxOn") SetActiveView(chatView) end)

local changelogBtn = CreateFrame("Button", "FikaTabChangelog", rootPanel, "UIPanelButtonTemplate")
StyleTabButton(changelogBtn)
changelogBtn:SetPoint("LEFT", chatBtn, "RIGHT", 4, 0)
changelogBtn:SetText("Changelog")
changelogBtn:SetScript("OnClick", function() PlaySound("igMainMenuOptionCheckBoxOn") SetActiveView(changelogView) end)

-------------------------------------------------------------------
-- 4. VIEW CONTENT: MAIN & OFFICER ADMIN
-------------------------------------------------------------------
local subtext = mainView:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
subtext:SetPoint("TOPLEFT", 0, 0)
subtext:SetText("Hantera dina yrken, specs och synka guildbanken smidigt.")

-- Documentation box
local docBox = CreateFrame("Frame", nil, mainView)
docBox:SetPoint("TOPLEFT", subtext, "BOTTOMLEFT", 0, -12)
docBox:SetPoint("BOTTOMRIGHT", mainView, "BOTTOMRIGHT", -16, 110)
docBox:SetBackdrop({
    bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background",
    edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
    tile = true, tileSize = 16, edgeSize = 12,
    insets = { left = 3, right = 3, top = 3, bottom = 3 }
})

local docScroll = CreateFrame("ScrollFrame", "FikaDocScrollFrame", docBox, "UIPanelScrollFrameTemplate")
docScroll:SetPoint("TOPLEFT", docBox, "TOPLEFT", 8, -8)
docScroll:SetPoint("BOTTOMRIGHT", docBox, "BOTTOMRIGHT", -28, 8)

local docInner = CreateFrame("Frame", nil, docScroll)
docInner:SetSize(360, 360)
docScroll:SetScrollChild(docInner)

local docText = docInner:CreateFontString(nil, "ARTWORK", "GameFontHighlight")
docText:SetPoint("TOPLEFT", 4, -4)
docText:SetWidth(350)
docText:SetJustifyH("LEFT")
docText:SetSpacing(4)
docText:SetText([[
|cffffd100Vad gör Fika?|r
Detta addon är ett verktyg för smidigare kommunikation mellan spelet, discord och våran hemsida.

Fika hjälper till att hålla koll på guildmedlemmars karaktärer och tillgångar i bakgrunden. Det är främst detta addonet och vår chattbot som driver det dynamiska på våran hemsida.

|cff00ccff1. Main, Specs & Yrken|r
Tillägget låter dig registrera och visa din Main-spec (MS), Off-spec (OS), yrkeslänkar samt namnet på din Main-karaktär direkt i guildfönstret.

|cff00ccff2. Rättigheter & Ändringar|r
Du kan ändra informationen för dina alts så länge du är inloggad på den karaktär som sparats som "Main". Officers i guilden har full behörighet och kan ändra eller rensa informationen för vem som helst direkt i gränssnittet.

|cff00ccff3. Automatiskt Guildbank-synk|r
Varje gång du öppnar en flik i din Guild Bank läser Fika av innehållet och synkar informationen direkt med vår bot.
*(Lösa planer finns på att lägga till funktioner för att bläddra i guildbanken på distans via tillägget i framtiden, men inga sådana försök har påbörjat ännu).*

|cffffd100Slash-kommandon:|r
•  |cffffffff/fika|r - Öppnar den här rutan på sekunden.
]])

-- Invite Button (Only visible if unguilded)
local inviteBtn = CreateFrame("Button", "FikaInviteButton", mainView, "UIPanelButtonTemplate")
inviteBtn:SetSize(160, 26)
inviteBtn:SetPoint("BOTTOMLEFT", mainView, "BOTTOMLEFT", 0, 16)
inviteBtn:SetText("Fråga efter guildinvite")

inviteBtn:SetScript("OnEnter", function(self)
    GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
    GameTooltip:AddLine("Fråga efter guildinvite", 1, 0.82, 0)
    GameTooltip:AddLine("Skickar ett viskmeddelande till botten för att bjuda in dig. Kräver att din karaktär har nått nivån för att kunna viska på servern.", 1, 1, 1, true)
    GameTooltip:Show()
end)
inviteBtn:SetScript("OnLeave", function() GameTooltip:Hide() end)
inviteBtn:SetScript("OnClick", function()
    SendChatMessage("Kanelbulle", "WHISPER", nil, "BotName")
end)

-- Officer Administration Tools
local adminHeader = mainView:CreateFontString(nil, "ARTWORK", "GameFontNormal")
adminHeader:SetPoint("TOPLEFT", docBox, "BOTTOMLEFT", 0, -12)
adminHeader:SetText("Administrationsverktyg (Endast Officers)")

addonTable.OrphanedCharacters = addonTable.OrphanedCharacters or {}
local selectedOrphan = nil

local dropBtn = CreateFrame("Button", "FikaDelcDropdown", mainView, "UIPanelButtonTemplate")
dropBtn:SetSize(150, 22)
dropBtn:SetPoint("TOPLEFT", adminHeader, "BOTTOMLEFT", 0, -6)
dropBtn:SetText("Välj karaktär...")

local dropMenu = CreateFrame("Frame", "FikaDelcMenu", mainView)
dropMenu:SetSize(150, 100)
dropMenu:SetPoint("TOPLEFT", dropBtn, "BOTTOMLEFT", 0, -2)
dropMenu:SetBackdrop({
    bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background",
    edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
    tile = true, tileSize = 16, edgeSize = 12,
    insets = { left = 3, right = 3, top = 3, bottom = 3 }
})
dropMenu:SetFrameStrata("TOOLTIP")
dropMenu:Hide()

local dropScroll = CreateFrame("ScrollFrame", "FikaDelcScroll", dropMenu, "UIPanelScrollFrameTemplate")
dropScroll:SetPoint("TOPLEFT", dropMenu, "TOPLEFT", 6, -6)
dropScroll:SetPoint("BOTTOMRIGHT", dropMenu, "BOTTOMRIGHT", -24, 6)

local dropContent = CreateFrame("Frame", nil, dropScroll)
dropContent:SetSize(120, 1)
dropScroll:SetScrollChild(dropContent)

local function RefreshMenuList()
    local children = { dropContent:GetChildren() }
    for _, child in ipairs(children) do child:Hide() child:SetParent(nil) end

    if #addonTable.OrphanedCharacters == 0 then
        local noData = dropContent:CreateFontString(nil, "ARTWORK", "GameFontDisableSmall")
        noData:SetPoint("TOPLEFT", 8, -6)
        noData:SetText("Inga saknade funna")
        dropBtn:SetText("Välj karaktär...")
        selectedOrphan = nil
        return
    end

    local offset = -4
    for i, name in ipairs(addonTable.OrphanedCharacters) do
        local item = CreateFrame("Button", nil, dropContent)
        item:SetSize(110, 18)
        item:SetPoint("TOPLEFT", 4, offset)
        
        local fontString = item:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
        fontString:SetPoint("LEFT", 4, 0)
        fontString:SetText(name)
        item:SetFontString(fontString)

        item:SetScript("OnClick", function()
            selectedOrphan = name
            dropBtn:SetText(name)
            dropMenu:Hide()
        end)
        
        offset = offset - 18
    end
    dropContent:SetHeight(math.abs(offset))
end

dropBtn:SetScript("OnClick", function()
    if dropMenu:IsShown() then dropMenu:Hide() else dropMenu:Show() end
end)

local delcBtn = CreateFrame("Button", "FikaDelcButton", mainView, "UIPanelButtonTemplate")
delcBtn:SetSize(80, 22)
delcBtn:SetPoint("LEFT", dropBtn, "RIGHT", 10, 0)
delcBtn:SetText("Ta bort")

delcBtn:SetScript("OnEnter", function(self)
    GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
    GameTooltip:AddLine("Ta bort från databas (DELC)", 1, 0.82, 0)
    GameTooltip:AddLine("Rensar den valda karaktären helt från både characters.json och professions.json i bottens databas.", 1, 1, 1, true)
    GameTooltip:Show()
end)
delcBtn:SetScript("OnLeave", function() GameTooltip:Hide() end)
delcBtn:SetScript("OnClick", function()
    if addonTable.networkDisabled then
        print("|cffff0000[FIKA]|r Åtgärden avbröts. Ditt addon-nätverk är avstängt pga. versionsfel.")
        return
    end

    if selectedOrphan and selectedOrphan ~= "" then
        SendAddonMessage("Fika", "DEL:" .. selectedOrphan, "GUILD")
        print(string.format("|cff00ccff[FIKA]|r Begäran skickad om att radera %s.", selectedOrphan))
        selectedOrphan = nil
        dropBtn:SetText("Välj karaktär...")
        SendAddonMessage("Fika", "QM:", "GUILD")
    end
end)

function addonTable:UpdateOrphanedCharacters(nameList)
    table.wipe(addonTable.OrphanedCharacters)
    if nameList and nameList ~= "" then
        for name in string.gmatch(nameList, "([^,]+)") do
            name = name:gsub("%s+", "")
            if name ~= "" then table.insert(addonTable.OrphanedCharacters, name) end
        end
    end
    RefreshMenuList()
end

-------------------------------------------------------------------
-- 5. VIEW CONTENT: CHAT INTEGRATION
-------------------------------------------------------------------
local subTitle = chatView:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
subTitle:SetPoint("TOPLEFT", 0, 0)
subTitle:SetText("Chat integrering")

local subDescription = chatView:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
subDescription:SetPoint("TOPLEFT", subTitle, "BOTTOMLEFT", 0, -8)
subDescription:SetText("Konfigurera hur information visas i spelets guildchatt samt Discord-länken.")

-- LIVE PREVIEW WINDOW ENGINE (RIGHT SIDE)
local previewBox = CreateFrame("Frame", nil, chatView)
previewBox:SetSize(280, 220)
previewBox:SetPoint("TOPRIGHT", chatView, "TOPRIGHT", -16, -40)
previewBox:SetBackdrop({
    bgFile = "Interface\\ChatFrame\\ChatFrameBackground",
    edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
    tile = true, tileSize = 16, edgeSize = 12,
    insets = { left = 3, right = 3, top = 3, bottom = 3 }
})
previewBox:SetBackdropColor(0, 0, 0, 0.75)

local previewTitle = previewBox:CreateFontString(nil, "ARTWORK", "GameFontNormalSmall")
previewTitle:SetPoint("BOTTOMLEFT", previewBox, "TOPLEFT", 4, 4)
previewTitle:SetText("Förhandsgranskning")

local discordLine = previewBox:CreateFontString(nil, "ARTWORK", "GameFontHighlight")
discordLine:SetPoint("TOPLEFT", 12, -16)
discordLine:SetWidth(256)
discordLine:SetJustifyH("LEFT")

local gmLine = previewBox:CreateFontString(nil, "ARTWORK", "GameFontHighlight")
gmLine:SetPoint("TOPLEFT", discordLine, "BOTTOMLEFT", 0, -20)
gmLine:SetWidth(256)
gmLine:SetJustifyH("LEFT")

local altLine = previewBox:CreateFontString(nil, "ARTWORK", "GameFontHighlight")
altLine:SetPoint("TOPLEFT", gmLine, "BOTTOMLEFT", 0, -20)
altLine:SetWidth(256)
altLine:SetJustifyH("LEFT")

local function RefreshLivePreviews()
    if not _G.FikaConfig then return end
    local cfg = _G.FikaConfig

    if cfg.enableDiscord then
        local icon = cfg.discordIcons and "|TInterface\\AddOns\\Fika\\Textures\\Discord.tga:14:14:0:0|t " or ""
        local suffix = not cfg.discordIcons and " (Discord)" or ""
        discordLine:SetText(string.format("[|cff40ff40G|r] %s[|cffc69b6dGmzco|r]%s: Hej allihopa från Discord!", icon, suffix))
    else
        discordLine:SetText("[|cff40ff40G|r] [Kyparen]: [Gmzco]: Hej allihopa från Discord!")
    end

    if cfg.enableGuildChat then
        local icon = cfg.guildMainSpecIcon and "|TInterface\\AddOns\\Fika\\Textures\\Tank.tga:14:14:0:0|t " or ""
        gmLine:SetText(string.format("[|cff40ff40G|r] %s[|cffc69b6dGmzco|r]: God kväll guilden.", icon))
    else
        gmLine:SetText("[|cff40ff40G|r] [Gmzco]: God kväll guilden.")
    end

    if cfg.enableGuildChat and (not cfg.guildChatOnly or true) then
        local s1 = cfg.guildMainSpecIcon and "|TInterface\\AddOns\\Fika\\Textures\\Healer.tga:14:14:0:0|t" or ""
        local s2 = cfg.guildOffSpecIcon and "|TInterface\\AddOns\\Fika\\Textures\\DPS.tga:14:14:0:0|t" or ""
        local iconPrefix = ""
        if s1 ~= "" or s2 ~= "" then
            iconPrefix = s1 .. (s1 ~= "" and s2 ~= "" and "/" or "") .. s2 .. " "
        end
        local mainSuffix = cfg.guildShowMainName and " (|cffc69b6dGmzco|r)" or ""
        altLine:SetText(string.format("[|cff40ff40G|r] %s[|cffffffffAlthena|r]%s: Kan jag få en invite till raiden?", iconPrefix, mainSuffix))
    else
        altLine:SetText("[|cff40ff40G|r] [Althena]: Kan jag få en invite till raiden?")
    end
end

local function CreateConfigCheckbox(parent, key, label, relativeTo, xOffset, yOffset)
    local cb = CreateFrame("CheckButton", "FikaCB_" .. key, parent, "InterfaceOptionsCheckButtonTemplate")
    cb:SetPoint("TOPLEFT", relativeTo, yOffset and "BOTTOMLEFT" or "TOPLEFT", xOffset, yOffset or 0)
    _G[cb:GetName() .. "Text"]:SetText(label)
    
    cb:SetScript("OnClick", function(self)
        if _G.FikaConfig then 
            _G.FikaConfig[key] = not not self:GetChecked() 
            RefreshLivePreviews()
        end
    end)
    return cb
end

local cbDiscord = CreateConfigCheckbox(chatView, "enableDiscord", "Förtydligad discord chat integration", subDescription, 0, -16)
local cbDiscordIcon = CreateConfigCheckbox(chatView, "discordIcons", "Använd ikon", cbDiscord, 20, -4)
local cbGuild = CreateConfigCheckbox(chatView, "enableGuildChat", "Förbättrad \"sändare\" i chatten", cbDiscordIcon, -20, -16)
local cbGuildOnly = CreateConfigCheckbox(chatView, "guildChatOnly", "Begränsa enbart till guildkanalen [G]", cbGuild, 20, -4)
local cbGuildMS = CreateConfigCheckbox(chatView, "guildMainSpecIcon", "Visa Main spec role ikon", cbGuildOnly, 0, -4)
local cbGuildOS = CreateConfigCheckbox(chatView, "guildOffSpecIcon", "Visa Off spec role ikon", cbGuildMS, 0, -4)
local cbGuildMain = CreateConfigCheckbox(chatView, "guildShowMainName", "Visa main karaktär", cbGuildOS, 0, -4)

local function UpdateCheckboxDependencies()
    if not _G.FikaConfig then return end
    if _G.FikaConfig.enableDiscord then cbDiscordIcon:Enable() else cbDiscordIcon:Disable() end
    if _G.FikaConfig.enableGuildChat then
        cbGuildOnly:Enable() cbGuildMS:Enable() cbGuildOS:Enable() cbGuildMain:Enable()
    else
        cbGuildOnly:Disable() cbGuildMS:Disable() cbGuildOS:Disable() cbGuildMain:Disable()
    end
end

cbDiscord:HookScript("OnClick", UpdateCheckboxDependencies)
cbGuild:HookScript("OnClick", UpdateCheckboxDependencies)

-------------------------------------------------------------------
-- 6. VIEW CONTENT: CHANGELOG
-------------------------------------------------------------------
local logTitle = changelogView:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
logTitle:SetPoint("TOPLEFT", 0, 0)
logTitle:SetText("Changelog")

local logSub = changelogView:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
logSub:SetPoint("TOPLEFT", logTitle, "BOTTOMLEFT", 0, -8)
logSub:SetText("Ändringshistorik för Fika addonet.")

local logBox = CreateFrame("Frame", nil, changelogView)
logBox:SetPoint("TOPLEFT", logSub, "BOTTOMLEFT", 0, -12)
logBox:SetPoint("BOTTOMRIGHT", changelogView, "BOTTOMRIGHT", -16, 16)
logBox:SetBackdrop({
    bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background",
    edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
    tile = true, tileSize = 16, edgeSize = 12,
    insets = { left = 3, right = 3, top = 3, bottom = 3 }
})

local logScroll = CreateFrame("ScrollFrame", "FikaLogScrollFrame", logBox, "UIPanelScrollFrameTemplate")
logScroll:SetPoint("TOPLEFT", logBox, "TOPLEFT", 8, -8)
logScroll:SetPoint("BOTTOMRIGHT", logBox, "BOTTOMRIGHT", -28, 8)

local logInner = CreateFrame("Frame", nil, logScroll)
logInner:SetSize(360, 400)
logScroll:SetScrollChild(logInner)

local logText = logInner:CreateFontString(nil, "ARTWORK", "GameFontHighlight")
logText:SetPoint("TOPLEFT", 4, -4)
logText:SetWidth(350)
logText:SetJustifyH("LEFT")
logText:SetSpacing(4)
logText:SetText([[
|cffffd100v0.3.0 - Versionskontroll|r
• Implementerat nätverkskontroll för versionshantering för att skydda addonet mot inkompatibla dataströmmar.

|cffffd100v0.2.0 - Bank & Konfiguration|r
• Lagt till automatisk synkronisering av guildbanken mot botten.
• Implementerat inställningspanelen med verktyg för administrativ databasrensning.
• Lagt till möjlighet för karaktärer utan guild att begära invite via knapptryck.
• Introducerat anpassad formatering och rollikoner för guildchatten och Discord-integrationen.

|cffffd100v0.1.0 - Enhetlig Spårning|r
• Utökat systemet till att hantera enhetliga karaktärslistor synkroniserat med yrkesdata.

|cffffd100v0.0.0 - Grundfunktioner|r
• Första implementationen av yrkesspårning och grundläggande kommunikation med Kyparen.
]])

-------------------------------------------------------------------
-- 7. VISIBILITY DRIVER HOOKS
-------------------------------------------------------------------
rootPanel:SetScript("OnShow", function()
    InitializeFikaConfig()
    
    if _G.FikaConfig then
        cbDiscord:SetChecked(_G.FikaConfig.enableDiscord)
        cbDiscordIcon:SetChecked(_G.FikaConfig.discordIcons)
        cbGuild:SetChecked(_G.FikaConfig.enableGuildChat)
        cbGuildOnly:SetChecked(_G.FikaConfig.guildChatOnly)
        cbGuildMS:SetChecked(_G.FikaConfig.guildMainSpecIcon)
        cbGuildOS:SetChecked(_G.FikaConfig.guildOffSpecIcon)
        cbGuildMain:SetChecked(_G.FikaConfig.guildShowMainName)
    end
    
    if IsInGuild() then inviteBtn:Hide() else inviteBtn:Show() end

    if CanEditOfficerNote() then
        adminHeader:Show() dropBtn:Show() delcBtn:Show()
        dropMenu:Hide()
        RefreshMenuList()
        if not addonTable.networkDisabled then
            SendAddonMessage("Fika", "QM:", "GUILD")
        end
    else
        adminHeader:Hide() dropBtn:Hide() delcBtn:Hide() dropMenu:Hide()
    end

    UpdateCheckboxDependencies()
    RefreshLivePreviews()
    
    -- Always reset visibility to the primary "Main" tab when opening the frame
    SetActiveView(mainView)
end)

-------------------------------------------------------------------
-- GLOBAL SLASH DRIVER
-------------------------------------------------------------------
_G.SLASH_FIKA1 = "/fika"
SlashCmdList["FIKA"] = function(msg)
    local testArgs = msg and msg:match("^test%s*(.*)$")
    
    if testArgs then
        local targetVersion = (testArgs ~= "") and testArgs or "0.3.0"
        print(string.format("|cff00ff00[FIKA TEST]|r Simulerar inkommande version V:%s från 'TestGubbe'...", targetVersion))
        
        local activeFrames = { GetFramesRegisteredForEvent("CHAT_MSG_ADDON") }
        for _, registeredFrame in ipairs(activeFrames) do
            local script = registeredFrame:GetScript("OnEvent")
            if script then
                pcall(script, registeredFrame, "CHAT_MSG_ADDON", "Fika", "V:" .. targetVersion, "GUILD", "TestGubbe-Gehennas")
            end
        end
    else
        InterfaceOptionsFrame_OpenToCategory(rootPanel)
        InterfaceOptionsFrame_OpenToCategory(rootPanel)
    end
end